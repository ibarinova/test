if (EMCKickstart === undefined) {
                var EMCKickstart = {};
            }
        EMCKickstart.webhelpLocales = {"ar-sa": true};
/**
 To add a topic, just add a line like:
 "key" : "url",
 That's the key in quotes, a colon, the url in quotes, followed by a comma.
 You can add comments by prefixing the line with double slash (//).
 **/
EMCKickstart.webhelpMap = {
	// Main Help File
	"main": "index.html",
	"CMDNAME_ELEMENT": "GUID-380481F2-AD86-4096-8890-F5CD4B36EFCA.html",
	"CODEBLOCK_ELEMENT": "GUID-5E89AC3A-66CE-4159-B201-62350F63260A.html",
	"FILEPATH_ELEMENT": "GUID-380481F2-AD86-4096-8890-F5CD4B36EFCA.html",
	"FN_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"KEYWORD_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"LINES_ELEMENT": "GUID-6F3184B9-AD11-4775-AE29-B5D62B31F799.html",
	"MSGPH_ELEMENT": "GUID-380481F2-AD86-4096-8890-F5CD4B36EFCA.html",
	"NOTE_ELEMENT": "GUID-5AC75408-612D-4C05-99FC-49DBC1BB5948.html",
	"PH_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"P_ELEMENT": "GUID-1022E39B-8749-45F2-B8C8-773539253B16.html",
	"Q_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"SUB_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"SUP_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"SYSTEM_OUTPUT_ELEMENT": "GUID-380481F2-AD86-4096-8890-F5CD4B36EFCA.html",
	"TERM_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"TM_ELEMENT": "GUID-57019B67-E99A-4827-804E-2B53B8EB5783.html",
	"USERINPUT_ELEMENT": "GUID-380481F2-AD86-4096-8890-F5CD4B36EFCA.html",

    // this is here so you don't have to worry about trailing commas
    "dummy": "/"
};

try {
	/**
	 * If an old URL is given, redirect to the corresponding topic from the WebHelp Responsive
	 */

	let actualLocation = encodeURIComponent(window.location.href);
	let newLocation;

	if (actualLocation.match(/[\w\.\-%]+\.htm(l)?%3F(topic|context)%3D([\w#\-]+)/gi) != null) {
		let linkSearchPosition = actualLocation.lastIndexOf("%3F");
		let linkTopicPosition = actualLocation.lastIndexOf("%2F");

		if (linkSearchPosition !== -1) {
			let linkSearch = actualLocation.substr(linkSearchPosition, actualLocation.length);
			let resourceId = linkSearch.split('%3D')[1];

			if (resourceId != null) {
				resourceId = ValidateAndSanitize(resourceId);
				$.each(EMCKickstart.webhelpMap, function (key, value) {
					if (key === resourceId) {
						newLocation = actualLocation.substr(0, linkTopicPosition) + "/" + encodeURIComponent(value);
						window.location.replace(decodeURIComponent(newLocation));
					}
				});
			}
		}
	}

	if (actualLocation.indexOf('%2F%23') !== -1) {
		newLocation = encodeURIComponent(actualLocation.replace(/%2F%23/g, "/%2F"));
		newLocation = newLocation.replace(/%5B/g, '[').replace(/%5D/g, ']');
		window.location.replace(decodeURIComponent(newLocation));
	}

	if (actualLocation.match(/%2Findex\.(.*)%23/gi)!=null) {
		newLocation = actualLocation.replace(/%2Findex\.(.*)%23/gi, "%2F");
		newLocation = newLocation.replace(/%5B/g, '[').replace(/%5D/g, ']');
		window.location.replace(decodeURIComponent(newLocation));
	}

} catch (err) {
	console.log("error occured : \n");
	console.log(err.message);
}
		