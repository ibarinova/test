document.addEventListener("DOMContentLoaded", () => {
    const navConfig = {

        attrs: {
            /* The state attribute name */
            state: "data-state",
            id: "data-id",
            tocID: "data-tocid"
        },

        states: {
            /* The possible states */
            pending: "pending",
            notReady: "not-ready",
            collapsed: "collapsed",
            expanded: "expanded",
            leaf: "leaf"
        },

        btnIds: {
            expand: "button-expand-action",
            collapse: "button-collapse-action",
            pending: "button-pending-action"
        },

        jsonBaseDir: "nav-links/json"
    };

    setTocHeight();

    $(window).resize(function () {
        setTocHeight();
    });

    loadTooltips($("#wh_publication_toc"));
    removeTargetBlank($("#wh_publication_toc"));

    $('.wh_publication_toc').scroll(function () {
        $('.wh_publication_toc .tooltip-container').find(".wh-tooltip").not(".hidden").addClass('hidden');
    });

    let topicRefExpandBtn = $(".wh_publication_toc .wh-expand-btn");

    topicRefExpandBtn.on( "click", function() {
        let topicRef = $( this ).closest(".topicref");
        setTimeout(function () {
            let nestedUl = $(topicRef.parent().get(0)).find('ul')[0];
            if ($(nestedUl).length) {
                loadTooltips($(nestedUl));
                removeTargetBlank($(nestedUl));
            }
        }, 100)
    } );

    // Register the click handler for the TOC 'Expand All' button
    let expandAllBtn = $(".wh_publication_toc #button-expand-action");
    expandAllBtn.removeClass('hidden');
    expandAllBtn.click(function () {
        tocExpandCollapseAll($('#wh_publication_toc'), 'expand');
    });

    // Register the ckick handler for the TOC 'Collapse All' button
    let collapseAllBtn = $(".wh_publication_toc #button-collapse-action");
    collapseAllBtn.click(function () {
        tocExpandCollapseAll($('#wh_publication_toc'), 'collapse');
    });

    function setTocHeight() {
        let tocContainer = $(".wh_publication_toc");
        let topicContainerHeight = $("#topic_content")[0].offsetHeight + 43;
        let contentRowViewHeight = $(window).height() - 90;

        if (topicContainerHeight > contentRowViewHeight) {
            tocContainer.height(topicContainerHeight);
        } else {
            tocContainer.height(contentRowViewHeight);
        }
    }

    function tocExpandCollapseAll($root, action) {
        let tocExpandBtns = $root.find('.wh-expand-btn');

        let collapseAllBtn = $(".wh_publication_toc #button-collapse-action");
        let expandAllBtn = $(".wh_publication_toc #button-expand-action");

        loadTooltips($root);
        removeTargetBlank($root);

        if (action === 'expand') {
            expandAllBtn.addClass('hidden');
            collapseAllBtn.removeClass('hidden');
        } else {
            collapseAllBtn.addClass('hidden');
            expandAllBtn.removeClass('hidden');
        }

        for (let index = 0; index < tocExpandBtns.length; ++index) {
            const tocExpandBtn = $(tocExpandBtns[index]);
            let topicRef = tocExpandBtn.closest(".topicref");
            let state = topicRef.attr(navConfig.attrs.state);

            if (action === 'collapse' && state === navConfig.states.expanded) {
                tocExpandBtn.click()
                let nestedUl = $(topicRef.parent().get(0)).find('ul')[0];
                if ($(nestedUl).length) {
                    tocExpandCollapseAll($(nestedUl), action);
                }
            } else if (action === 'expand' && state !== navConfig.states.expanded) {
                tocExpandBtn.click()
                setTimeout(function () {
                    let nestedUl = $(topicRef.parent().get(0)).find('ul')[0];
                    if ($(nestedUl).length) {
                        tocExpandCollapseAll($(nestedUl), action);
                    }
                }, 60)
            }
        }
    }

    function loadJS(t, id, e) {
        let n = document.createElement("script");
        n.setAttribute("id", id)
        n.src = t, n.onload = e, n.onreadystatechange = e, document.body.appendChild(n)
    }

    // Remove target="_blank". Oxygen issue.
    function removeTargetBlank($root) {
        setTimeout(function () {
            $root.find('a[target="_blank"]').removeAttr('target');
        }, 100)
    }

    // Loads tooltips into tooltips container.
    function loadTooltips($root) {
        let topicRefs = $root.find('.topicref');

        for (let index = 0; index < topicRefs.length; ++index) {
            let topicRef = $(topicRefs[index]);

            loadTopicrefTooltip(topicRef);

            topicRef.hover(toggleTopicrefTooltipShow);
            topicRef.mouseleave(toggleTopicrefTooltipHide);
        }
    }

    function loadTopicrefTooltip(topicRef) {
        let tocId = topicRef.attr(navConfig.attrs.tocID);
        let tooltipContainer = $('.wh_publication_toc .tooltip-container');
        let topicTooltip = tooltipContainer.find("[data-toc-id='" + tocId + "']");

        if (tocId != null && topicTooltip.length === 0) {
            let jsonHref = "./oxygen-webhelp/app/nav-links/json/" + tocId + ".js";
            let scriptId = tocId + '-script';
            loadJS(jsonHref, scriptId, (function () {
                let root = Object.keys(oxy_webhelp_navlinks)
                let navData = oxy_webhelp_navlinks[root]
                let shortdescValue = navData.shortdesc;

                if (shortdescValue !== undefined) {
                    let tooltipSpan = $('<span class="wh-tooltip hidden"/>').append(shortdescValue);
                    tooltipSpan.attr('data-toc-id', tocId);
                    tooltipContainer.append(tooltipSpan);
                }
            }));
            $("#" + scriptId).remove();
        }
    }

    function toggleTopicrefTooltipShow() {
        let topicId = $(this).attr(navConfig.attrs.tocID);
        let tooltipContainer = $('#wh_publication_toc .tooltip-container');
        let topicTooltip = tooltipContainer.find("[data-toc-id='" + topicId + "']");

        let topicOffsetTop = $(this).offset().top;
        let topicOffsetLeft = $(this).offset().left;
        let topicTitleWidth = $(this).find('.title')[0].offsetWidth;

        if (topicTooltip.length === 1) {
            topicTooltip.removeClass('hidden');
            if ($('html').attr('dir') === 'rtl') {
                topicTooltip.offset({top: topicOffsetTop - 8, left: topicOffsetLeft - topicTooltip[0].offsetWidth});
            } else {
                topicTooltip.offset({top: topicOffsetTop - 8, left: topicOffsetLeft + topicTitleWidth + 30});
            }
        }
    }

    function toggleTopicrefTooltipHide() {
        let topicId = $(this).attr(navConfig.attrs.tocID);
        let tooltipContainer = $('#wh_publication_toc .tooltip-container');
        let topicTooltip = tooltipContainer.find("[data-toc-id='" + topicId + "']");
        if (topicTooltip.length === 1) {
            topicTooltip.addClass('hidden')
        }
    }
});
