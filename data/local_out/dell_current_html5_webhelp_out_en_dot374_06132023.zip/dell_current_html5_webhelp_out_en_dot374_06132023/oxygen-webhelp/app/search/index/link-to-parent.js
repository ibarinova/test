/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
var linkToParent = {};
