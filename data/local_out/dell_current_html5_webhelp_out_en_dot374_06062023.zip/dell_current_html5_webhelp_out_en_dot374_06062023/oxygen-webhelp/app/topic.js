var WebHelpAPI;
(() => {
    "use strict";
    var t, e = {
        1266: (t, e, n) => {
            n.r(e), n.d(e, {DOMSanitizer: () => i});
            var o = n(7856), r = n.n(o);

            function a(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            r().addHook("afterSanitizeAttributes", (function (t) {
                "target" in t && (t.setAttribute("target", "_blank"), t.setAttribute("rel", "noopener"))
            }));
            var i = function () {
                function t() {
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t)
                }

                var e, n;
                return e = t, n = [{
                    key: "appendHtmlNode", value: function (t, e) {
                        var n = r().sanitize(t[0]);
                        e.append(n)
                    }
                }, {
                    key: "appendElementNodeToBody", value: function (t) {
                        var e = r().sanitize(t, {RETURN_DOM: !0, RETURN_DOM_IMPORT: !0});
                        return document.body.appendChild(e.firstChild)
                    }
                }, {
                    key: "sanitize", value: function (t) {
                        return r().sanitize(t, {ALLOWED_TAGS: []})
                    }
                }], null && a(e.prototype, null), n && a(e, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }()
        }, 8650: (t, e, n) => {
            n.r(e), n.d(e, {stickyController: () => y});
            var o = n(4290), r = n(3193);

            function a(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function i(t, e) {
                l(t, e), e.add(t)
            }

            function l(t, e) {
                if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
            }

            function c(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                return n
            }

            var s = new WeakMap, u = new WeakSet, p = new WeakSet, f = new WeakSet, h = new WeakSet;

            function d(t) {
                var e = !1;
                return t && (e = !0), e
            }

            function v() {
                c(this, f, w).call(this, window.location.hash)
            }

            function w(t, e) {
                if (!(n = this, o = s, r = function (t, e, n) {
                    if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                    return e.get(t)
                }(n, o), function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(n, r)).test(t)) return !1;
                var n, o, r, a = document.getElementById(t.slice(1));
                if (a) {
                    var i = a.getBoundingClientRect(), l = window.pageYOffset + i.top - this.getStickyOffset();
                    window.scrollTo(window.pageXOffset, l), history && history.pushState && e && history.pushState({}, document.title, location.pathname + t)
                }
                return !!a
            }

            function b(t) {
                var e = t.target;
                "A" === e.nodeName && c(this, f, w).call(this, e.getAttribute("href"), !0) && t.preventDefault()
            }

            var y = new (function () {
                function t() {
                    var e, n;
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), i(this, h), i(this, f), i(this, p), i(this, u), n = {
                        writable: !0,
                        value: /^#[^ ]+$/
                    }, l(this, e = s), e.set(this, n)
                }

                var e, n;
                return e = t, (n = [{
                    key: "init", value: function () {
                        var t = this, e = r(".wh_header");
                        c(this, u, d).call(this, e) && (e.addClass("header-sticky"), e.css({top: "0"}), e.outerHeight());
                        var n = r(".wh_tools").parent();
                        c(this, u, d).call(this, n) && (n.addClass("breadcrumb-sticky"), n.css({top: e.outerHeight()}), n.outerHeight());
                        var a = r(".wh-letters");
                        c(this, u, d).call(this, a) && (a.addClass("indexTerms-sticky"), a.css({top: e.outerHeight()})), c(this, p, v).call(this), window.addEventListener("hashchange", (function () {
                            return c(t, p, v).call(t)
                        })), document.body.addEventListener("click", (function (e) {
                            return c(t, h, b).call(t, e)
                        }));
                        try {
                            var i = document.getElementsByClassName("wh_header")[0];
                            new ResizeObserver((function () {
                                n.css({top: e.outerHeight()}), a.css({top: e.outerHeight()})
                            })).observe(i)
                        } catch (t) {
                            o.Z.debug("ResizeObserver is not supported.", t)
                        }
                    }
                }, {
                    key: "getStickyOffset", value: function () {
                        var t = 0, e = r(".wh_header");
                        c(this, u, d).call(this, e) && (t += e.outerHeight());
                        var n = r(".wh_tools").parent();
                        return c(this, u, d).call(this, n) && (t += n.outerHeight()), t
                    }
                }]) && a(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }())
        }, 8091: (t, e, n) => {
            n.r(e), n.d(e, {Options: () => i});
            var o = n(4093), r = n.n(o);

            function a(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            var i = function () {
                function t() {
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t)
                }

                var e, n;
                return e = t, n = [{
                    key: "get", value: function (t) {
                        return r()[t]
                    }
                }, {
                    key: "getBoolean", value: function (t) {
                        var e = r()[t];
                        return "true" == e || "yes" == e
                    }
                }, {
                    key: "getInteger", value: function (t) {
                        var e = r()[t];
                        return parseInt(e, 10)
                    }
                }, {
                    key: "getIndexerLanguage", value: function () {
                        var t = this.get("webhelp.language");
                        if (t) {
                            var e = t.indexOf("_");
                            -1 != e && (t = t.substring(0, e))
                        }
                        return t
                    }
                }], null && a(e.prototype, null), n && a(e, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }()
        }, 2404: (t, e, n) => {
            n.r(e), n.d(e, {AutocompleteItem: () => Yn, setCustomAutocomplete: () => Kn}), n(2390), n(3734);
            var o = n(3193);

            function r(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            var a = n(1266).DOMSanitizer, i = new WeakSet;

            function l(t, e) {
                var n = document.createElement("textarea");
                n.style.position = "fixed", n.value = t, (n = a.appendElementNodeToBody(n)).select();
                try {
                    if (document.execCommand("copy"), 0 == e.find(".wh-tooltip").length) {
                        var r = o('<span>  <span class="wh-tooltip"><p class="wh-tooltip-content">Copied to clipboard</p></span></span>');
                        e.prepend(r), e.mouseleave((function () {
                            r.remove()
                        })), setTimeout((function () {
                            r.remove()
                        }), 3e3)
                    }
                } catch (t) {
                    if (0 == e.find(".wh-tooltip").length) {
                        var i = o('<span>  <span class="wh-tooltip"><p class="wh-tooltip-content">Oops, unable to copy</p></span></span>');
                        e.mouseleave((function () {
                            i.remove()
                        })), e.prepend(i), setTimeout((function () {
                            i.remove()
                        }), 3e3)
                    }
                    util.debug("Oops, unable to copy codeblock content!", t)
                }
                document.body.removeChild(n)
            }

            var c = new (function () {
                function t() {
                    var e, n;
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), function (t, e) {
                        if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                    }(e = this, n = i), n.add(e)
                }

                var e, n;
                return e = t, (n = [{
                    key: "init", value: function () {
                        var t = this;
                        o(".codeblock").on("mouseover", (function (e) {
                            var n = o('<span class="copyTooltip wh-tooltip-container" data-tooltip-position="left"/>');
                            0 == o(e.currentTarget).find(".copyTooltip").length && (o(e.currentTarget).prepend(n), o(".codeblock .copyTooltip").on("click", (function (e) {
                                var n = o(e.currentTarget).closest(".codeblock").text();
                                n && "" != n && function (t, e, n) {
                                    if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                                    return n
                                }(t, i, l).call(t, n, o(e.currentTarget))
                            })))
                        })), o(".codeblock").on("mouseleave", (function (t) {
                            o(t.currentTarget).find(".copyTooltip").remove()
                        }))
                    }
                }]) && r(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }()), s = n(8091);
            const u = localization;
            var p = n.n(u);

            function f(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            var h = function () {
                function t() {
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t)
                }

                var e, n;
                return e = t, n = [{
                    key: "getLocalization", value: function (t) {
                        var e = t;
                        return t in p() && (e = p()[t]), e
                    }
                }], null && f(e.prototype, null), n && f(e, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }(), d = n(3193);

            function v(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function w(t, e) {
                !function (t, e) {
                    if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                }(t, e), e.add(t)
            }

            function b(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                return n
            }

            var y = new WeakSet, g = new WeakSet;

            function m(t, e) {
                var n = d(t).parent().siblings(":not(.wh_not_expandable)");
                if (void 0 !== e) "collapsed" == e ? (n.slideUp(0), d(".webhelp_expand_collapse_sections").attr("data-next-state", "expanded").attr("title", h.getLocalization("expandSections")), d(t).removeClass("expanded"), d(t).attr("aria-expanded", !1), d(t).attr("aria-label", h.getLocalization("expand"))) : (n.slideDown(0), d(".webhelp_expand_collapse_sections").attr("data-next-state", "collapsed").attr("title", h.getLocalization("collapseSections")), d(t).addClass("expanded"), d(t).attr("aria-expanded", !0), d(t).attr("aria-label", h.getLocalization("collapse"))); else {
                    d(t).toggleClass("expanded");
                    var o = d(t).hasClass("expanded");
                    d(t).attr("aria-expanded", o), o ? d(t).attr("aria-label", h.getLocalization("collapse")) : d(t).attr("aria-label", h.getLocalization("expand"));
                    var r = d(t).parent();
                    "CAPTION" == r.prop("tagName") || r.hasClass("wh_first_letter") ? n.toggle() : n.slideToggle("1000")
                }
            }

            function _(t) {
                t.siblings(":hidden").addClass("wh_not_expandable")
            }

            var k = new (function () {
                function t() {
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), w(this, g), w(this, y)
                }

                var e, n;
                return e = t, (n = [{
                    key: "init", value: function () {
                        var t = this, e = s.Options.get("webhelp.topic.collapsible.elements.initial.state");
                        ["table > caption:not(:empty)", ".topic:not(:first-child) > .title", ".sectiontitle:not(.tasklabel)", ".wh_term_group > .wh_first_letter"].forEach((function (e) {
                            var n = d(document).find(e);
                            n.siblings(":not(:hidden)").length > 0 && (n.prepend(d("<span>", {
                                class: "wh_expand_btn expanded",
                                role: "button",
                                "aria-expanded": "true",
                                tabindex: 0,
                                "aria-label": h.getLocalization("collapse")
                            })), b(t, g, _).call(t, n))
                        })), d(".wh-letters a").on("click", (function (t) {
                            var e = d(t.currentTarget).attr("href").replace("#", "");
                            t.preventDefault(), history.replaceState({}, "", t.target.href), d("[id='" + e + "']").length > 0 && d("html, body").animate({scrollTop: d("[id='" + e + "']").offset().top}, 1e3)
                        })), d.each(d(document).find(".wh_expand_btn"), (function (n, o) {
                            b(t, y, m).call(t, o, e)
                        })), d(".webhelp_expand_collapse_sections").on("click", (function (e) {
                            var n = d(".webhelp_expand_collapse_sections").attr("data-next-state");
                            return d.each(d(document).find(".wh_expand_btn"), (function (e, o) {
                                b(t, y, m).call(t, o, n)
                            })), !1
                        })), d(".wh_topic_toc a").on("click", (function (e) {
                            var n = d(e.currentTarget).attr("href"), o = d(n);
                            o.length && (d.each(o.parents(), (function () {
                                d(e.currentTarget).children(".title").length && b(this, y, m).call(this, d(e.currentTarget).children(".title").find(".wh_expand_btn"), "expanded")
                            })), b(t, y, m).call(t, o.children(".title").find(".wh_expand_btn"), "expanded"))
                        }));
                        var n = d(document).find(".wh_expand_btn");
                        n.on("click", (function (e) {
                            return b(t, y, m).call(t, e.currentTarget), !1
                        })), n.on("keypress", (function (e) {
                            13 !== e.which && 32 !== e.which || (e.preventDefault(), b(t, y, m).call(t, e.currentTarget))
                        }))
                    }
                }]) && v(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }()), O = n(3193);

            function T(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            var S = n(8091).Options, C = n(8650).stickyController, x = new (function () {
                function t() {
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t)
                }

                var e, n;
                return e = t, (n = [{
                    key: "init", value: function () {
                        [".dt[id]", ".section[id] .sectiontitle", ".title.topictitle2[id]", "table[id] .tablecap"].forEach((function (t) {
                            O(document).find(t).append("<span class='permalink'/>")
                        })), O("span.permalink").on("click", (function (t) {
                            var e = O(t.currentTarget).closest("[id]").attr("id"), n = "#" + e;
                            if (t.preventDefault(), history.replaceState({}, "", n), S.getBoolean("webhelp.enable.sticky.header")) {
                                var o = C.getStickyOffset();
                                O("html, body").animate({scrollTop: O("[id='" + e + "']").offset().top - o}, 1e3)
                            } else O("html, body").animate({scrollTop: O("[id='" + e + "']").offset().top}, 1e3)
                        }))
                    }
                }]) && T(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }()), j = n(8650), P = n(4290), E = (n(2993), n(3193));

            function I(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function W(t, e) {
                R(t, e), e.add(t)
            }

            function R(t, e) {
                if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
            }

            function z(t, e) {
                var n = function (t, e, n) {
                    if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                    return e.get(t)
                }(t, e);
                return function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(t, n)
            }

            function A(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                return n
            }

            var H = new WeakMap, D = new WeakSet, M = new WeakSet, L = new WeakSet, N = function () {
                function t() {
                    var e, n;
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), W(this, L), W(this, M), W(this, D), n = {
                        writable: !0,
                        value: 30
                    }, R(this, e = H), e.set(this, n)
                }

                var e, n;
                return e = t, (n = [{
                    key: "addSearchQueryToHistory", value: function (t) {
                        if (P.Z.debug("Add search query to history: ", t), A(this, D, B).call(this)) {
                            t = t.toLowerCase();
                            var e = A(this, M, Z).call(this);
                            try {
                                var n = window.localStorage.getItem(e);
                                if (n) {
                                    var o = JSON.parse(n), r = o.indexOf(t);
                                    -1 != r && (P.Z.debug("Promote history item:", o), o.splice(r, 1)), o.unshift(t), o.length > z(this, H) && o.splice(z(this, H));
                                    var a = JSON.stringify(o);
                                    window.localStorage.setItem(e, a)
                                } else {
                                    var i = [];
                                    i.push(t);
                                    var l = JSON.stringify(i);
                                    P.Z.debug("Save to local storage: ", l), window.localStorage.setItem(e, l)
                                }
                            } catch (t) {
                                P.Z.debug("Exception when trying to save to local storage: ", t), window.localStorage.removeItem(e)
                            }
                        } else P.Z.debug("Local storage is not available")
                    }
                }, {
                    key: "getHistorySearchItems", value: function () {
                        var t = [];
                        if (A(this, D, B).call(this)) {
                            var e = A(this, M, Z).call(this);
                            try {
                                var n = window.localStorage.getItem(e);
                                if (n) {
                                    var o = JSON.parse(n);
                                    Array.isArray(o) && (t = o)
                                }
                            } catch (t) {
                                P.Z.debug("Exception when reading from local storage: ", t), window.localStorage.removeItem(e)
                            }
                        }
                        return t
                    }
                }, {
                    key: "removeSearchHistoryItem", value: function (t) {
                        var e = !1;
                        if (A(this, D, B).call(this)) {
                            var n = A(this, M, Z).call(this);
                            try {
                                var o = window.localStorage.getItem(n);
                                if (o) {
                                    var r = JSON.parse(o);
                                    if (Array.isArray(r)) {
                                        t = t.toLowerCase();
                                        var a = r.indexOf(t);
                                        if (-1 != a) {
                                            r.splice(a, 1);
                                            var i = JSON.stringify(r);
                                            window.localStorage.setItem(n, i), e = !0
                                        }
                                    }
                                }
                            } catch (t) {
                                P.Z.debug("Exception when removing from local storage: ", t), window.localStorage.removeItem(n)
                            }
                        }
                        return e
                    }
                }]) && I(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }();

            function B() {
                try {
                    var t = window.localStorage, e = "__storage_test__";
                    return t.setItem(e, e), t.removeItem(e), !0
                } catch (t) {
                    return P.Z.debug(t), !1
                }
            }

            function Z() {
                var t = E("meta[name=wh-path2root]").attr("content");
                return null == t || null == t || 0 == t.length ? t = "index.html" : t += "index.html", A(this, L, U).call(this, t) + "_search_history_items"
            }

            function U(t) {
                var e = document.createElement("a");
                return e.href = t, e.protocol + "//" + e.host + e.pathname + e.search + e.hash
            }

            var J = n(1266), F = n(3193);

            function $(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function q(t, e) {
                G(t, e), e.add(t)
            }

            function Q(t, e, n) {
                G(t, e), e.set(t, n)
            }

            function G(t, e) {
                if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
            }

            function X(t, e) {
                return function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(t, V(t, e, "get"))
            }

            function Y(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                return n
            }

            function K(t, e, n) {
                return function (t, e, n) {
                    if (e.set) e.set.call(t, n); else {
                        if (!e.writable) throw new TypeError("attempted to set read only private field");
                        e.value = n
                    }
                }(t, V(t, e, "set"), n), n
            }

            function V(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to " + n + " private field on non-instance");
                return e.get(t)
            }

            var tt = new WeakMap, et = new WeakMap, nt = new WeakSet, ot = new WeakSet, rt = new WeakSet,
                at = new WeakSet, it = function () {
                    function t() {
                        !function (t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), q(this, at), q(this, rt), q(this, ot), q(this, nt), Q(this, tt, {
                            writable: !0,
                            value: void 0
                        }), Q(this, et, {writable: !0, value: void 0}), K(this, tt, new N)
                    }

                    var e, n;
                    return e = t, (n = [{
                        key: "install", value: function () {
                            var t = this;
                            if (s.Options.getBoolean("webhelp.enable.search.autocomplete")) {
                                var e = F("#textToSearch").autocomplete({
                                    source: function (e, n) {
                                        return Y(t, nt, lt).call(t, e, n)
                                    }, minLength: 3
                                });
                                F("#textToSearch").on("keydown", (function (t) {
                                    13 == t.which && F("#textToSearch").val().trim().length > 1 && (F("#textToSearch").autocomplete("close"), F("#searchForm").trigger("submit"))
                                })), e.data("ui-autocomplete")._renderItem = function (e, n) {
                                    for (var o = F("#textToSearch").val(), r = (o = o.toLowerCase()).split(" "), a = n.label.split(" "), i = F("<span>", {
                                        class: "search-autocomplete-proposal-label",
                                        "data-value": n.value
                                    }), l = 0; l < a.length; l++) {
                                        var c = a[l];
                                        if (c.trim().length > 0) {
                                            for (var s = !1, u = 0; u < r.length; u++) {
                                                var p = r[u].trim();
                                                if (p.length > 0) {
                                                    try {
                                                        p = p.replace("\\", "\\\\").replace(")", "\\)").replace("(", "\\(");
                                                        var f = c.replace(new RegExp("(" + p + ")", "i"), "<span class='not-inserted'>$1</span>")
                                                    } catch (t) {
                                                        debug(t)
                                                    }
                                                    if (f !== c) {
                                                        var h = F("<span>", {class: "search-autocomplete-proposal-hg"}).text(c);
                                                        J.DOMSanitizer.appendHtmlNode(h, i), s = !0;
                                                        break
                                                    }
                                                }
                                            }
                                            if (!s) {
                                                var d = document.createTextNode(c);
                                                i.append(d)
                                            }
                                            l < a.length - 1 && i.append(" ")
                                        }
                                    }
                                    var v = "&nbsp;";
                                    "history" == n.type && (v = "h");
                                    var w, b = F("<span>", {class: "search-autocomplete-proposal-icon " + n.type, html: v});
                                    if ("history" == n.type) {
                                        var y = F("<a>", {class: "oxy-icon oxy-icon-remove", "data-value": n.value});
                                        w = F("<span>", {class: "search-autocomplete-proposal-type-history"}), J.DOMSanitizer.appendHtmlNode(y, w);
                                        var g = F(w).find("a");
                                        g.on("click", (function (e) {
                                            return Y(t, ot, ct).call(t, g[0]), e.preventDefault(), e.stopPropagation(), !1
                                        }))
                                    }
                                    var m = F("<li>", {class: "ui-menu-item", "data-value": n.value}),
                                        _ = F("<div>", {class: "ui-menu-item-wrapper"});
                                    return m.append(_), _.append(b), J.DOMSanitizer.appendHtmlNode(i, _), null != w && _.append(w), m.find(".ui-menu-item-wrapper").on("click", (function (t) {
                                        F("#textToSearch").val(F(this).find(".search-autocomplete-proposal-label").attr("data-value")), F("#searchForm").trigger("submit")
                                    })), m.appendTo(e)
                                }, F(window).on("resize", (function () {
                                    F("#textToSearch").autocomplete("instance").search()
                                })), F(window).on("scroll", (function () {
                                    F("#textToSearch").autocomplete("close")
                                }))
                            }
                        }
                    }, {
                        key: "addStringToAutocompleteHistory", value: function (t) {
                            X(this, tt).addSearchQueryToHistory(t)
                        }
                    }, {
                        key: "getHistorySearchItems", value: function () {
                            return X(this, tt).getHistorySearchItems()
                        }
                    }, {
                        key: "setCustomAutocomplete", value: function (t) {
                            K(this, et, t)
                        }
                    }]) && $(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
                }();

            function lt(t, e) {
                var n = t.term.toLowerCase(), o = Y(this, rt, st).call(this, n), r = [];
                if (null != X(this, et)) X(this, et).getOptions(n, (function (t) {
                    var n = [];
                    n = (n = n.concat(o)).concat(t), e(n)
                })); else {
                    var a = [];
                    if (void 0 !== keywordsInfo) for (var i, l = keywordsInfo.keywords, c = keywordsInfo.ph, s = n.split(" "), u = 0; u < s.length; u++) {
                        var p = s[u].trim();
                        if (p.length > 0) {
                            for (var f = [], h = 0; h < l.length; h++) if (0 == l[h].w.toLowerCase().indexOf(p)) for (var d = l[h].p, v = 0; v < d.length; v++) {
                                var w = d[v];
                                (0 == u || -1 != a.indexOf(w)) && f.push(w)
                            }
                            a = f
                        }
                    }
                    if (a.length > 0) for (var b = 0; b < a.length; b++) {
                        var y = c[a[b]], g = "";
                        for (u = 0; u < y.length; u++) {
                            var m = l[y[u]].w;
                            0 == u && (m = m.charAt(0).toUpperCase() + m.substr(1)), g += m, u < y.length - 1 && (g += " ")
                        }
                        for (h = 0; h < o.length; h++) if (g.toLocaleLowerCase() == o[h]) {
                            i = !0;
                            break
                        }
                        if (null == i) {
                            var _ = {label: g.toLowerCase(), value: g.toLowerCase(), type: "title"};
                            r.push(_)
                        }
                    } else {
                        var k = s[s.length - 1], O = t.term.substring(0, n.lastIndexOf(k));
                        for (h = 0; h < l.length; h++) if (0 == l[h].w.toLowerCase().indexOf(p)) {
                            for (var T = O + l[h].w, S = 0; S < o.length; S++) if (T.toLocaleLowerCase() == o[S]) {
                                i = !0;
                                break
                            }
                            null == i && (_ = {
                                label: T.toLowerCase(),
                                value: T.toLowerCase(),
                                type: "keyword"
                            }, r.push(_))
                        }
                    }
                    var C = [];
                    C = (C = C.concat(o)).concat(r), e(C)
                }
            }

            function ct(t) {
                var e = t.getAttribute("data-value");
                X(this, tt).removeSearchHistoryItem(e) && (F(t).attr("class", "oxy-icon oxy-icon-ok"), F(t).parents("div").find(".search-autocomplete-proposal-label").addClass("removed-from-history"))
            }

            function st(t) {
                var e = [], n = X(this, tt).getHistorySearchItems();
                if (null != n) for (var o = t.split(" "), r = 0; r < n.length; r++) if (Y(this, at, ut).call(this, n[r], o)) {
                    var a = {label: n[r], value: n[r], type: "history"};
                    e.push(a)
                }
                return e
            }

            function ut(t, e) {
                for (var n = t.split(" "), o = !0, r = 0; r < e.length && o; r++) {
                    var a = e[r].trim();
                    if (a.length > 0) {
                        for (var i = !1, l = 0; l < n.length; l++) if (0 == n[l].toLowerCase().indexOf(a.toLowerCase())) {
                            i = !0;
                            break
                        }
                        o = o && i
                    }
                }
                return o
            }

            var pt = s.Options.getBoolean("webhelp.enable.search.autocomplete") && !s.Options.getBoolean("webhelp.custom.search.engine.enabled"),
                ft = new it, ht = n(3193);

            function dt(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function vt(t, e, n) {
                !function (t, e) {
                    if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                }(t, e), e.set(t, n)
            }

            function wt(t, e) {
                return function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(t, yt(t, e, "get"))
            }

            function bt(t, e, n) {
                return function (t, e, n) {
                    if (e.set) e.set.call(t, n); else {
                        if (!e.writable) throw new TypeError("attempted to set read only private field");
                        e.value = n
                    }
                }(t, yt(t, e, "set"), n), n
            }

            function yt(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to " + n + " private field on non-instance");
                return e.get(t)
            }

            var gt = new WeakMap, mt = new WeakMap, _t = function () {
                function t(e, n) {
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), vt(this, gt, {writable: !0, value: void 0}), vt(this, mt, {
                        writable: !0,
                        value: void 0
                    }), bt(this, gt, e), bt(this, mt, n)
                }

                var e, n;
                return e = t, (n = [{
                    key: "initialize", value: function () {
                        wt(this, mt) && wt(this, gt).install(), ht("#searchForm").on("submit", (function (t) {
                            if ("" == ht("#textToSearch").val().trim()) return t.preventDefault(), t.stopPropagation(), !1
                        }))
                    }
                }, {
                    key: "addStringToAutocompleteHistory", value: function (t) {
                        wt(this, mt) && wt(this, gt).addStringToAutocompleteHistory(t)
                    }
                }, {
                    key: "keepLastSearchExpression", value: function () {
                        if (wt(this, mt) && null != P.Z.getParameter("hl")) {
                            var t = wt(this, gt).getHistorySearchItems();
                            null != t[0] ? ht("#textToSearch").val(t[0]) : ht("#textToSearch").val("")
                        }
                    }
                }]) && dt(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }(), kt = new _t(ft, pt), Ot = n(3193);

            function Tt(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function St(t, e) {
                var n = function (t, e, n) {
                    if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                    return e.get(t)
                }(t, e);
                return function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(t, n)
            }

            var Ct = new WeakMap, xt = function () {
                function t() {
                    var e, n, o;
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), o = {writable: !0, value: 20}, function (t, e) {
                        if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                    }(e = this, n = Ct), n.set(e, o)
                }

                var e, n;
                return e = t, (n = [{
                    key: "_computeStickyElementsPositions", value: function () {
                        var t = Ot(".wh_search_input").outerHeight(!0);
                        Ot(".wh_search_input").parents(".wh_header").length && (t = 0);
                        var e = Ot(".wh_tools").parent().outerHeight(), n = Ot(".wh_header").outerHeight(), o = 0,
                            r = 0, a = 0;
                        if (s.Options.getBoolean("webhelp.enable.sticky.header")) a = t, o = e + n + (Ot(window).scrollTop() > t ? 0 : t - Ot(window).scrollTop()), r = parseInt(Ot(window).height()) - o; else {
                            a = e + n + t - St(this, Ct);
                            var i = e + n + t;
                            Ot(window).scrollTop() > i ? i = St(this, Ct) : i -= Ot(window).scrollTop(), o = i, r = parseInt(Ot(window).height()) - o
                        }
                        return {topOffset: o, visibleAreaHeight: r, buttonOffset: a}
                    }
                }]) && Tt(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }(), jt = n(3193);

            function Pt(t) {
                return Pt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
                    return typeof t
                } : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, Pt(t)
            }

            function Et(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function It() {
                return It = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (t, e, n) {
                    var o = Wt(t, e);
                    if (o) {
                        var r = Object.getOwnPropertyDescriptor(o, e);
                        return r.get ? r.get.call(arguments.length < 3 ? t : n) : r.value
                    }
                }, It.apply(this, arguments)
            }

            function Wt(t, e) {
                for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = At(t));) ;
                return t
            }

            function Rt(t, e) {
                return Rt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
                    return t.__proto__ = e, t
                }, Rt(t, e)
            }

            function zt(t, e) {
                if (e && ("object" === Pt(e) || "function" == typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return function (t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t
                }(t)
            }

            function At(t) {
                return At = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
                    return t.__proto__ || Object.getPrototypeOf(t)
                }, At(t)
            }

            var Ht = new (function (t) {
                !function (t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                    t.prototype = Object.create(e && e.prototype, {
                        constructor: {
                            value: t,
                            writable: !0,
                            configurable: !0
                        }
                    }), Object.defineProperty(t, "prototype", {writable: !1}), e && Rt(t, e)
                }(i, t);
                var e, n, o, r, a = (o = i, r = function () {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function () {
                        }))), !0
                    } catch (t) {
                        return !1
                    }
                }(), function () {
                    var t, e = At(o);
                    if (r) {
                        var n = At(this).constructor;
                        t = Reflect.construct(e, arguments, n)
                    } else t = e.apply(this, arguments);
                    return zt(this, t)
                });

                function i() {
                    return function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, i), a.call(this)
                }

                return e = i, (n = [{
                    key: "handlePositionOnScreen", value: function () {
                        var t = jt(".wh_publication_toc"), e = jt("#wh_publication_toc"), n = jt("#wh_topic_body"),
                            o = jt("#wh_publication_toc_content");
                        if (t.length > 0 && n.length > 0 && s.Options.getBoolean("webhelp.enable.sticky.publication.toc")) {
                            var r = It(At(i.prototype), "_computeStickyElementsPositions", this).call(this),
                                a = r.topOffset, l = r.visibleAreaHeight, c = r.buttonOffset,
                                u = parseInt(o.height()) + parseInt(o.css("padding-top")) + parseInt(o.css("padding-bottom")) + parseInt(o.css("margin-top")) + parseInt(o.css("margin-bottom")),
                                p = u - (parseInt(t.height()) + parseInt(t.css("padding-top")) + parseInt(t.css("padding-bottom")) + parseInt(t.css("margin-top")) + parseInt(t.css("margin-bottom"))),
                                f = parseInt(e.outerWidth()) - parseInt(e.css("padding-left")) - parseInt(e.css("padding-right"));
                            if ((p < .1 * l || u < l) && parseInt(jt(window).width()) > 767) {
                                o.css("top", a + "px").css("width", f + "px").css("position", "fixed").css("z-index", "997").css("display", "flex").css("flex-direction", "column"), t.css("overflow-y", "auto").css("overflow-x", "hidden");
                                var h = jt(".wh_footer")[0].getBoundingClientRect().top;
                                l + a > h ? o.css("max-height", l - (jt(window).height() - h) - 30) : o.css("max-height", l - 30), jt(window).scrollTop() > c ? jt("#wh_close_publication_toc_button").css("top", jt(window).scrollTop() - c - 5) : jt("#wh_close_publication_toc_button").css("top", "-5px"), jt("#wh_close_publication_toc_button").css("left", -1 * e.outerWidth() + 5)
                            } else jt("#wh_close_publication_toc_button").css("top", "-5px"), jt("#wh_close_publication_toc_button").css("left", -1 * Math.round(e.outerWidth()) + 5), o.removeAttr("style"), t.removeAttr("style")
                        } else jt("#wh_close_publication_toc_button").css("top", "-5px"), jt("#wh_close_publication_toc_button").css("left", -1 * e.outerWidth() + 5)
                    }
                }, {
                    key: "toggleExpandCollapse", value: function (t, e) {
                        if (t.length) {
                            var n = 9;
                            if (e.length && (n = 7, e.hasClass("d-lg-none") && (n = 9)), t.hasClass("d-md-block") && t.is(":visible")) {
                                jt("#wh_close_publication_toc_button").attr("aria-expanded", !1), jt("#wh_toc_button").attr("aria-expanded", !1), jt("#wh_close_publication_toc_button").addClass("clicked"), t.removeClass("col-lg-".concat(3, " col-md-").concat(3)), t.removeClass("d-block"), t.removeClass("d-md-block"), t.addClass("d-none"), t.addClass("d-md-none");
                                var o = jt(".wh_topic_content").parent();
                                void 0 !== o && (o.removeClass("col-lg-".concat(n, " col-md-9")), o.addClass("col-lg-".concat(n + 3, " col-md-12")), o.addClass("closed-publication-toc"))
                            } else {
                                jt("#wh_close_publication_toc_button").attr("aria-expanded", !0), jt("#wh_toc_button").attr("aria-expanded", !0), jt("#wh_close_publication_toc_button").removeClass("clicked"), t.addClass("col-lg-".concat(3, " col-md-").concat(3)), t.removeClass("d-none"), t.removeClass("d-md-none"), t.addClass("d-block"), t.addClass("d-md-block");
                                var r = jt(".wh_topic_content").parent();
                                void 0 !== r && (r.removeClass("col-lg-".concat(n + 3, " col-md-12")), r.removeClass("closed-publication-toc"), r.addClass("col-lg-".concat(n, " col-md-9")));
                                var a = parseInt(t.outerWidth()) - parseInt(t.css("padding-left")) - parseInt(t.css("padding-right"));
                                jt("#wh_publication_toc_content").css("width", a)
                            }
                            jt("#wh_close_publication_toc_button").css("left", -1 * jt("#wh_publication_toc").outerWidth() + 5)
                        }
                    }
                }, {
                    key: "displayActiveTopic", value: function () {
                        var t = jt(".wh_publication_toc"), e = jt("#wh_topic_body");
                        if (t.length > 0 && e.length > 0) {
                            var n = jt(".wh_publication_toc").offset().top,
                                o = n + parseInt(jt(".wh_publication_toc").outerHeight()),
                                r = jt(".wh_publication_toc .active > .topicref a").offset().top;
                            if (r > .8 * o) {
                                var a = (n + o) / 2;
                                jt(".wh_publication_toc").animate({scrollTop: r - a}, 0)
                            }
                        }
                    }
                }]) && Et(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), i
            }(xt)), Dt = n(3193);

            function Mt(t) {
                return Mt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
                    return typeof t
                } : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, Mt(t)
            }

            function Lt(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function Nt() {
                return Nt = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (t, e, n) {
                    var o = Bt(t, e);
                    if (o) {
                        var r = Object.getOwnPropertyDescriptor(o, e);
                        return r.get ? r.get.call(arguments.length < 3 ? t : n) : r.value
                    }
                }, Nt.apply(this, arguments)
            }

            function Bt(t, e) {
                for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = Ft(t));) ;
                return t
            }

            function Zt(t, e) {
                return Zt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
                    return t.__proto__ = e, t
                }, Zt(t, e)
            }

            function Ut(t, e) {
                if (e && ("object" === Mt(e) || "function" == typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return Jt(t)
            }

            function Jt(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t
            }

            function Ft(t) {
                return Ft = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
                    return t.__proto__ || Object.getPrototypeOf(t)
                }, Ft(t)
            }

            function $t(t, e) {
                !function (t, e) {
                    if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                }(t, e), e.add(t)
            }

            function qt(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                return n
            }

            var Qt = new WeakSet, Gt = new WeakSet;

            function Xt(t) {
                var e = this, n = void 0 !== t ? Math.round(t) : 0,
                    o = Dt(".wh_tools").parent().outerHeight() + Dt(".wh_header").outerHeight();
                n += o;
                var r = null != location.hash ? location.hash : "", a = null != Dt(r).offset() ? Dt(r).offset().top : 0,
                    i = "" != r ? Math.round(a) : 0;
                if ("" != r.substr(1) && i >= n - 75 && i <= n + 75) {
                    Dt("#wh_topic_toc a").removeClass("current_node");
                    var l = Dt('#wh_topic_toc a[data-tocid = "' + r.substr(1) + '"]');
                    l.length && (l.addClass("current_node"), qt(this, Gt, Yt).call(this, l))
                } else Dt.each(Dt(".wh_topic_content .title"), (function (t, o) {
                    var r = Dt(o).parent().attr("id");
                    if (r && Dt('.wh_topic_toc a[data-tocid = "' + r + '"]').length) {
                        var a = Math.round(Dt(o).offset().top);
                        if (a >= n - 75 && a <= n + 75) {
                            Dt(".wh_topic_toc a").removeClass("current_node");
                            var i = Dt('.wh_topic_toc a[data-tocid = "' + r + '"]');
                            i.addClass("current_node"), qt(e, Gt, Yt).call(e, i)
                        }
                    }
                }))
            }

            function Yt(t) {
                var e = Dt(".wh_topic_toc").offset().top, n = parseInt(Dt(".wh_topic_toc").outerHeight()),
                    o = t.offset().top - e;
                if (o > .7 * n || o < .2 * n) {
                    var r = n / 2;
                    Dt(".wh_topic_toc").animate({scrollTop: Dt(".wh_topic_toc").scrollTop() + o - r}, 0)
                }
            }

            var Kt = new (function (t) {
                !function (t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                    t.prototype = Object.create(e && e.prototype, {
                        constructor: {
                            value: t,
                            writable: !0,
                            configurable: !0
                        }
                    }), Object.defineProperty(t, "prototype", {writable: !1}), e && Zt(t, e)
                }(i, t);
                var e, n, o, r, a = (o = i, r = function () {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function () {
                        }))), !0
                    } catch (t) {
                        return !1
                    }
                }(), function () {
                    var t, e = Ft(o);
                    if (r) {
                        var n = Ft(this).constructor;
                        t = Reflect.construct(e, arguments, n)
                    } else t = e.apply(this, arguments);
                    return Ut(this, t)
                });

                function i() {
                    var t;
                    return function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, i), $t(Jt(t = a.call(this)), Gt), $t(Jt(t), Qt), t
                }

                return e = i, (n = [{
                    key: "handlePositionOnScreen", value: function () {
                        var t = Dt("#wh_topic_toc"), e = Dt(".wh_topic_toc"), n = Dt("#wh_topic_toc_content");
                        if (e.length > 0 && s.Options.getBoolean("webhelp.enable.sticky.topic.toc")) {
                            var o = Nt(Ft(i.prototype), "_computeStickyElementsPositions", this).call(this),
                                r = o.topOffset, a = o.visibleAreaHeight, l = o.buttonOffset;
                            qt(this, Qt, Xt).call(this, Dt(window).scrollTop());
                            var c = parseInt(n.height()) + parseInt(n.css("padding-top")) + parseInt(n.css("padding-bottom")) + parseInt(n.css("margin-top")) + parseInt(n.css("margin-bottom")),
                                u = c - (parseInt(e.height()) + parseInt(e.css("padding-top")) + parseInt(e.css("padding-bottom")) + parseInt(e.css("margin-top")) + parseInt(e.css("margin-bottom"))),
                                p = parseInt(t.outerWidth()) - parseInt(t.css("padding-left")) - parseInt(t.css("padding-right"));
                            if ((u < .1 * a || c < a) && parseInt(Dt(window).width()) > 767) {
                                n.css("top", r + "px").css("position", "fixed").css("width", p + "px").css("display", "flex").css("flex-direction", "column"), e.css("overflow-y", "auto").css("overflow-x", "hidden");
                                var f = Dt(".wh_footer")[0].getBoundingClientRect().top;
                                a + r > f ? n.css("max-height", a - (Dt(window).height() - f) - 30) : n.css("max-height", a - 30), Dt(window).scrollTop() > l ? Dt("#wh_close_topic_toc_button").css("top", Dt(window).scrollTop() - l - 5) : Dt("#wh_close_topic_toc_button").css("top", "-5px"), Dt("#wh_close_topic_toc_button").css("right", -1 * Math.round(t.outerWidth()) + 5)
                            } else n.removeAttr("style"), e.removeAttr("style"), Dt("#wh_close_topic_toc_button").css("top", "-5px"), Dt("#wh_close_topic_toc_button").css("right", -1 * Math.round(t.outerWidth()) + 5)
                        } else Dt("#wh_close_topic_toc_button").css("top", "-5px"), Dt("#wh_close_topic_toc_button").css("right", -1 * Math.round(t.outerWidth()) + 5)
                    }
                }, {
                    key: "toggleExpandCollapse", value: function (t, e) {
                        if (e.length) {
                            var n = 10;
                            if (t.length && (n = 7, t.hasClass("d-md-none") && (n = 10)), e.hasClass("d-lg-block")) Dt("#wh_close_topic_toc_button").addClass("clicked"), Dt("#wh_close_topic_toc_button").attr("aria-expanded", !1), e.removeClass("d-lg-block"), e.addClass("d-lg-none"), void 0 !== (o = Dt(".wh_topic_content").parent()) && (o.removeClass("col-lg-".concat(n)), o.addClass("col-lg-".concat(n + 2)), o.addClass("closed-page-toc")); else {
                                var o;
                                Dt("#wh_close_topic_toc_button").removeClass("clicked"), Dt("#wh_close_topic_toc_button").attr("aria-expanded", !0), e.removeClass("d-lg-none"), e.addClass("d-lg-block"), void 0 !== (o = Dt(".wh_topic_content").parent()) && (o.removeClass("col-lg-".concat(n + 2)), o.removeClass("closed-page-toc"), o.addClass("col-lg-".concat(n)));
                                var r = parseInt(e.outerWidth()) - parseInt(e.css("padding-left")) - parseInt(e.css("padding-right"));
                                Dt("#wh_topic_toc_content").css("width", r)
                            }
                            Dt("#wh_close_topic_toc_button").css("right", -1 * Math.round(Dt("#wh_topic_toc").outerWidth()) + 5)
                        }
                    }
                }]) && Lt(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), i
            }(xt)), Vt = n(3193);

            function te(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function ee(t, e) {
                if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
            }

            function ne(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to " + n + " private field on non-instance");
                return e.get(t)
            }

            var oe = new WeakMap, re = new WeakSet;

            function ae() {
                if (P.Z.debug("highlightSearchTerm()"), !function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(this, ne(this, oe, "get"))) {
                    try {
                        var t = Vt(".wh_topic_content"), e = Vt(".wh_related_links"), n = Vt(".wh_child_links");
                        if (void 0 !== t.unhighlight) {
                            t.unhighlight(), e.unhighlight();
                            var o = P.Z.getParameter("hl");
                            if (null != o) {
                                var r = decodeURIComponent(String(o));
                                if (P.Z.debug("jsonString: ", r), void 0 !== r && "" != r) {
                                    var a = r.split(",");
                                    P.Z.debug("words: ", a);
                                    for (var i = 0; i < a.length; i++) P.Z.debug("highlight(" + a[i] + ");"), t.highlight(a[i]), e.highlight(a[i]), n.highlight(a[i]);
                                    if (s.Options.getBoolean("webhelp.enable.scroll.to.search.term")) {
                                        var l = Vt(".highlight").first();
                                        void 0 !== l && Vt("html, body").animate({scrollTop: l.offset().top - j.stickyController.getStickyOffset()}, 0)
                                    }
                                }
                            }
                        }
                    } catch (t) {
                        P.Z.debug(t)
                    }
                    !function (t, e, n) {
                        (function (t, e, n) {
                            if (e.set) e.set.call(t, n); else {
                                if (!e.writable) throw new TypeError("attempted to set read only private field");
                                e.value = n
                            }
                        })(t, ne(t, e, "set"), n)
                    }(this, oe, !0)
                }
            }

            var ie = new (function () {
                function t() {
                    var e;
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), ee(this, e = re), e.add(this), function (t, e, n) {
                        ee(t, e), e.set(t, {writable: !0, value: !1})
                    }(this, oe)
                }

                var e, n;
                return e = t, (n = [{
                    key: "init", value: function () {
                        Vt("html > body").addClass("doc-ready"), Ht.handlePositionOnScreen(), Kt.handlePositionOnScreen(), Vt(window).on("scroll", (function () {
                            Ht.handlePositionOnScreen(), Kt.handlePositionOnScreen()
                        })), Vt(window).on("resize", (function () {
                            Vt("#wh_publication_toc").removeAttr("style"), Ht.handlePositionOnScreen(), Kt.handlePositionOnScreen()
                        })), Ht.displayActiveTopic();
                        var t = Vt(".topic.nested1").length, e = Vt("section.section .title").length;
                        (t > 1 || e > 1) && Vt(".webhelp_expand_collapse_sections").show(), Vt(".dots-before").on("click", (function (t) {
                            Vt(t.currentTarget).siblings(".hide-before").show(), Vt(t.currentTarget).hide()
                        })), Vt(".dots-after").on("click", (function (t) {
                            Vt(t.currentTarget).siblings(".hide-after").show(), Vt(t.currentTarget).hide()
                        })), s.Options.getBoolean("webhelp.show.full.size.image") && (Vt.each(Vt("img.image:not([usemap])"), (function (t, e) {
                            var n = Vt(e).parent().get(0).tagName;
                            e.naturalWidth > e.width && "a" != n.toLowerCase() && Vt(e).addClass("zoom")
                        })), Vt(".zoom").on("click", (function (t) {
                            Vt("#modal_img_large").css("display", "block"), Vt("#modal_img_container").append('<img class="modal-content" id="modal-img" alt="" />'), Vt("#modal-img").attr("src", Vt(t.currentTarget).attr("src")), Vt("#caption").text(J.DOMSanitizer.sanitize(Vt(t.currentTarget).attr("alt")))
                        }))), Vt(".modal .close").on("click", (function () {
                            Vt(".modal").css("display", "none")
                        })), Vt(document).on("keyup", (function (t) {
                            27 == t.keyCode && Vt("#modal_img_large").is(":visible") && Vt(".modal").css("display", "none")
                        })), Vt("#topic_navigation_links .navprev>a").addClass("oxy-icon oxy-icon-arrow-left"), Vt("#topic_navigation_links .navnext>a").addClass("oxy-icon oxy-icon-arrow-right"), Vt(".wh_print_link button").addClass("oxy-icon oxy-icon-print");
                        var n = Vt("#wh_publication_toc"), o = Vt("#wh_topic_toc");
                        if (void 0 !== n) if (0 == n.find("*").length) {
                            n.css("display", "none"), n.removeClass("col-lg-4 col-md-4 col-sm-4 col-xs-12");
                            var r = Vt(".wh_topic_content").parent();
                            void 0 !== r && null == o && (r.removeClass(" col-lg-8 col-md-8 col-sm-8 col-xs-12 "), r.addClass(" col-lg-12 col-md-12 col-sm-12 col-xs-12 "))
                        } else {
                            var a = n.find(".topicref .wh-tooltip .shortdesc:empty");
                            a.length > 0 && a.closest(".wh-tooltip").remove()
                        }
                        o.length && (Vt("#wh_close_topic_toc_button").removeClass("d-none"), Vt("#wh_close_topic_toc_button").addClass("d-lg-block")), n.length && (Vt("#wh_close_publication_toc_button").removeClass("d-none"), Vt("#wh_close_publication_toc_button").addClass("d-md-block")), Vt("#wh_close_topic_toc_button").on("click", (function () {
                            return Kt.toggleExpandCollapse(n, o)
                        })), Vt("#wh_close_publication_toc_button").on("click", (function () {
                            return Ht.toggleExpandCollapse(n, o)
                        })), Vt("#wh_toc_button").on("click", (function () {
                            return Ht.toggleExpandCollapse(n, o)
                        }));
                        var i = Vt(".wh_breadcrumb").find(".topicref .wh-tooltip .shortdesc:empty");
                        i.length > 0 && i.closest(".wh-tooltip").remove(), Vt(".wh_main_page_toc a").on("click", (function (t) {
                            t.stopImmediatePropagation()
                        })), function (t, e, n) {
                            if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                            return n
                        }(this, re, ae).call(this), Vt(window).on("scroll", (function (t) {
                            Vt(t.currentTarget).scrollTop() > 5 ? Vt("#go2top").fadeIn("fast") : Vt("#go2top").fadeOut("fast")
                        })), Vt("#go2top").on("click", (function () {
                            return Vt("html, body").animate({scrollTop: 0}, 800), !1
                        })), Vt(".wh_hide_highlight").on("click", (function (t) {
                            Vt(".highlight").addClass("wh-h"), Vt(".wh-h").toggleClass("highlight"), Vt(t.currentTarget).toggleClass("hl-close")
                        })), null != P.Z.getParameter("hl") && Vt(".wh_hide_highlight").show()
                    }
                }]) && te(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }()), le = (n(288), n(3193));

            function ce(t, e) {
                var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!n) {
                    if (Array.isArray(t) || (n = function (t, e) {
                        if (t) {
                            if ("string" == typeof t) return se(t, e);
                            var n = Object.prototype.toString.call(t).slice(8, -1);
                            return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? se(t, e) : void 0
                        }
                    }(t)) || e && t && "number" == typeof t.length) {
                        n && (t = n);
                        var o = 0, r = function () {
                        };
                        return {
                            s: r, n: function () {
                                return o >= t.length ? {done: !0} : {done: !1, value: t[o++]}
                            }, e: function (t) {
                                throw t
                            }, f: r
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                var a, i = !0, l = !1;
                return {
                    s: function () {
                        n = n.call(t)
                    }, n: function () {
                        var t = n.next();
                        return i = t.done, t
                    }, e: function (t) {
                        l = !0, a = t
                    }, f: function () {
                        try {
                            i || null == n.return || n.return()
                        } finally {
                            if (l) throw a
                        }
                    }
                }
            }

            function se(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, o = new Array(e); n < e; n++) o[n] = t[n];
                return o
            }

            function ue(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            var pe = new WeakSet;

            function fe(t) {
                var e, n = ce(t);
                try {
                    for (n.s(); !(e = n.n()).done;) {
                        var o = e.value, r = Number(o.getAttribute("width")), a = o.width;
                        0 != r && r != a && function () {
                            var t, e = 100 - Math.round((r - a) / r * 100),
                                n = ce(o.parentNode.parentNode.querySelector(o.getAttribute("usemap")).childNodes);
                            try {
                                for (n.s(); !(t = n.n()).done;) {
                                    var i = t.value;
                                    i.coords = i.coords.split(", ").map((function (t) {
                                        return Math.floor(t * e / 100)
                                    })).join(", ")
                                }
                            } catch (t) {
                                n.e(t)
                            } finally {
                                n.f()
                            }
                        }()
                    }
                } catch (t) {
                    n.e(t)
                } finally {
                    n.f()
                }
            }

            var he = new (function () {
                    function t() {
                        var e, n;
                        !function (t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), function (t, e) {
                            if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                        }(e = this, n = pe), n.add(e)
                    }

                    var e, n;
                    return e = t, (n = [{
                        key: "init", value: function () {
                            var t = le("img[usemap]");
                            t.length > 0 && (t.maphilight(), function (t, e, n) {
                                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                                return n
                            }(this, pe, fe).call(this, t))
                        }
                    }]) && ue(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
                }()), de = "data-state", ve = "data-tocid", we = "pending", be = "not-ready", ye = "collapsed",
                ge = "expanded", me = "leaf", _e = "button-expand-action", ke = "button-collapse-action",
                Oe = "button-pending-action", Te = n(3193);

            function Se(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function Ce(t, e, n) {
                return function (t, e, n) {
                    if (e.set) e.set.call(t, n); else {
                        if (!e.writable) throw new TypeError("attempted to set read only private field");
                        e.value = n
                    }
                }(t, je(t, e, "set"), n), n
            }

            function xe(t, e) {
                return function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(t, je(t, e, "get"))
            }

            function je(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to " + n + " private field on non-instance");
                return e.get(t)
            }

            var Pe = new WeakMap, Ee = function () {
                function t() {
                    var e, n, o;
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), o = {writable: !0, value: null}, function (t, e) {
                        if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                    }(e = this, n = Pe), n.set(e, o)
                }

                var e, n;
                return e = t, (n = [{
                    key: "_getPathToRoot", value: function () {
                        return null == xe(this, Pe) && (Ce(this, Pe, Te('meta[name="wh-path2root"]').attr("content")), null != xe(this, Pe) && null != xe(this, Pe) || Ce(this, Pe, "")), xe(this, Pe)
                    }
                }]) && Se(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }(), Ie = n(3193);

            function We(t) {
                return We = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
                    return typeof t
                } : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, We(t)
            }

            function Re(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function ze(t, e) {
                return ze = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
                    return t.__proto__ = e, t
                }, ze(t, e)
            }

            function Ae(t, e) {
                if (e && ("object" === We(e) || "function" == typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return He(t)
            }

            function He(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t
            }

            function De() {
                return De = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (t, e, n) {
                    var o = Me(t, e);
                    if (o) {
                        var r = Object.getOwnPropertyDescriptor(o, e);
                        return r.get ? r.get.call(arguments.length < 3 ? t : n) : r.value
                    }
                }, De.apply(this, arguments)
            }

            function Me(t, e) {
                for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = Le(t));) ;
                return t
            }

            function Le(t) {
                return Le = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
                    return t.__proto__ || Object.getPrototypeOf(t)
                }, Le(t)
            }

            function Ne(t, e) {
                !function (t, e) {
                    if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                }(t, e), e.add(t)
            }

            function Be(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                return n
            }

            var Ze = new WeakSet, Ue = new WeakSet, Je = new WeakSet, Fe = new WeakSet, $e = new WeakSet,
                qe = new WeakSet, Qe = new WeakSet, Ge = new WeakSet, Xe = new WeakSet, Ye = new WeakSet,
                Ke = function (t) {
                    !function (t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                writable: !0,
                                configurable: !0
                            }
                        }), Object.defineProperty(t, "prototype", {writable: !1}), e && ze(t, e)
                    }(i, t);
                    var e, n, o, r, a = (o = i, r = function () {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function () {
                            }))), !0
                        } catch (t) {
                            return !1
                        }
                    }(), function () {
                        var t, e = Le(o);
                        if (r) {
                            var n = Le(this).constructor;
                            t = Reflect.construct(e, arguments, n)
                        } else t = e.apply(this, arguments);
                        return Ae(this, t)
                    });

                    function i() {
                        var t;
                        return function (t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, i), Ne(He(t = a.call(this)), Ye), Ne(He(t), Xe), Ne(He(t), Ge), Ne(He(t), Qe), Ne(He(t), qe), Ne(He(t), $e), Ne(He(t), Fe), Ne(He(t), Je), Ne(He(t), Ue), Ne(He(t), Ze), t
                    }

                    return e = i, (n = [{
                        key: "init", value: function () {
                            var t = this;
                            Ie(".wh_publication_toc .title").on("mouseenter", (function (e) {
                                return Be(t, Ze, Ve).call(t, e)
                            })), Ie(".wh_publication_toc .title").on("mouseleave", (function () {
                                return Be(t, Ue, tn).call(t)
                            })), Ie(window).on("scroll", (function () {
                                return Be(t, Ue, tn).call(t)
                            })), Ie(".wh_publication_toc").on("scroll", (function () {
                                return Be(t, Ue, tn).call(t)
                            }));
                            var e = Ie(".wh_publication_toc .wh-expand-btn");
                            e.on("click", (function (e) {
                                return Be(t, Fe, nn).call(t, e)
                            })), e.on("keypress", (function (e) {
                                return Be(t, Je, en).call(t, e)
                            }))
                        }
                    }]) && Re(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), i
                }(Ee);

            function Ve(t) {
                var e = Ie(t.currentTarget).find(".wh-tooltip");
                if (e.length > 0) {
                    var n = Ie("<div>", {
                        class: "wh-tooltip-wrapper",
                        "data-tooltip-position": Ie(".wh_publication_toc").attr("data-tooltip-position")
                    }), o = e.clone();
                    o.removeClass("wh-tooltip"), o.addClass("wh-toc-tooltip"), n.append(o);
                    var r = Ie(t.currentTarget).offset().top - Ie("#wh_publication_toc").offset().top,
                        a = Ie(t.currentTarget).offset().left - (Ie("#wh_publication_toc").offset().left + parseInt(Ie("#wh_publication_toc").css("padding-left")));
                    n.css("position", "absolute").css("top", r).css("left", a).css("width", Ie(t.currentTarget).width() + a).css("height", Ie(t.currentTarget).height()).css("float", "left"), J.DOMSanitizer.appendHtmlNode(n, Ie("#wh_publication_toc")), setTimeout((function () {
                        Ie(".wh-toc-tooltip").addClass("wh-display-tooltip")
                    }), 50)
                }
            }

            function tn() {
                Ie("#wh_publication_toc>.wh-tooltip-wrapper").remove()
            }

            function en(t) {
                13 !== t.which && 32 !== t.which || (t.preventDefault(), Be(this, Fe, nn).call(this, t))
            }

            function nn(t) {
                var e = Ie(t.currentTarget).closest(".topicref"), n = e.attr(de), o = Ie(t.currentTarget).closest("li"),
                    r = Ie(t.currentTarget).siblings(".title").children("a").attr("id");
                null == n || n == we || (n == be ? (e.attr(de, we), o.attr("aria-expanded", "true"), Ie(t.currentTarget).attr("aria-labelledby", Oe + " " + r), Be(this, $e, on).call(this, e)) : n == ge ? (e.attr(de, ye), Ie(t.currentTarget).attr("aria-labelledby", _e + " " + r), o.attr("aria-expanded", "false")) : n == ye && (e.attr(de, ge), Ie(t.currentTarget).attr("aria-labelledby", ke + " " + r), o.attr("aria-expanded", "true")))
            }

            function on(t) {
                var e = this, n = Ie(t).attr(ve);
                null != n && P.Z.loadJS("./" + De(Le(Ke.prototype), "_getPathToRoot", this).call(this) + "oxygen-webhelp/app/nav-links/json/" + n + ".js", (function () {
                    var o = oxy_webhelp_navlinks[n];
                    if (null != o) {
                        var r = o.topics, a = t.closest("li"), i = Be(e, qe, rn).call(e, r),
                            l = Ie('<ul role="group"/>');
                        i.forEach((function (t) {
                            return l.append(t)
                        })), a.append(l);
                        var c = t.find(".title > a").attr("id");
                        t.children(".wh-expand-btn").attr("aria-labelledby", ke + " " + c), t.attr(de, ge)
                    } else t.attr(de, me)
                }))
            }

            function rn(t) {
                var e = this, n = [];
                return t.forEach((function (t) {
                    var o = Be(e, Qe, an).call(e, t);
                    n.push(o)
                })), n
            }

            function an(t) {
                var e = Ie("<li>");
                e.attr("role", "treeitem"), Be(this, Ye, sn).call(this, t) && e.attr("aria-expanded", "false");
                var n = Be(this, Ge, ln).call(this, t);
                return e.append(n), e
            }

            function ln(t) {
                var e = this, n = "external" == t.scope, o = Ie("<div>");
                o.addClass("topicref"), null != t.outputclass && o.addClass(t.outputclass);
                var r = t.attributes;
                void 0 !== r && Object.keys(r).forEach((function (t) {
                    return o.attr(t, r[t])
                })), o.attr(ve, t.tocID);
                var a = Be(this, Ye, sn).call(this, t);
                a ? o.attr(de, be) : o.attr(de, me);
                var i = Ie("<span>", {class: "wh-expand-btn", role: "button"});
                a && (i.attr("aria-labelledby", _e + " " + Be(this, Xe, cn).call(this, t)), i.attr("tabindex", "0")), i.on("click", (function (t) {
                    return Be(e, Fe, nn).call(e, t)
                })), i.on("keypress", (function (t) {
                    return Be(e, Je, en).call(e, t)
                })), o.append(i);
                var l = "";
                null != t.href && "javascript:void(0)" != t.href && (n || (l += De(Le(Ke.prototype), "_getPathToRoot", this).call(this)), l += t.href);
                var c = Ie("<a>", {href: l, html: t.title}),
                    s = De(Le(Ke.prototype), "_getPathToRoot", this).call(this);
                c.find("a[href]").each((function (t, e) {
                    var n = Ie(e).attr("href");
                    n.startsWith("http:") || n.startsWith("https:") || Ie(e).attr("href", s + n)
                })), c.find("img[src]").each((function (t, e) {
                    var n = Ie(e).attr("src");
                    n.startsWith("http:") || n.startsWith("https:") || Ie(e).attr("src", s + n)
                })), c.attr("id", Be(this, Xe, cn).call(this, t)), n && c.attr("target", "_blank");
                var u = Ie("<div>", {class: "title"});
                if (u.on("mouseenter", (function (t) {
                    return Be(e, Ze, Ve).call(e, t)
                })), u.on("mouseleave", (function () {
                    return Be(e, Ue, tn).call(e)
                })), J.DOMSanitizer.appendHtmlNode(c, u), null != t.shortdesc) {
                    var p = Ie("<div>", {class: "wh-tooltip", html: t.shortdesc});
                    0 == p.find(".shortdesc:empty").length && (p.find("a[href]").each((function (t, e) {
                        var n = Ie(e).attr("href");
                        n.startsWith("http:") || n.startsWith("https:") || Ie(e).attr("href", s + n)
                    })), p.find("img[src]").each((function (t, e) {
                        var n = Ie(e).attr("src");
                        n.startsWith("http:") || n.startsWith("https:") || Ie(e).attr("src", s + n)
                    })), u.append(p))
                }
                return o.append(u), o
            }

            function cn(t) {
                return t.tocID + "-link"
            }

            function sn(t) {
                var e = t.topics;
                return null == e || 0 != e.length
            }

            var un = new Ke, pn = n(3193);

            function fn(t) {
                return fn = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
                    return typeof t
                } : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, fn(t)
            }

            function hn(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function dn(t, e) {
                return dn = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
                    return t.__proto__ = e, t
                }, dn(t, e)
            }

            function vn(t, e) {
                if (e && ("object" === fn(e) || "function" == typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return wn(t)
            }

            function wn(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t
            }

            function bn() {
                return bn = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (t, e, n) {
                    var o = yn(t, e);
                    if (o) {
                        var r = Object.getOwnPropertyDescriptor(o, e);
                        return r.get ? r.get.call(arguments.length < 3 ? t : n) : r.value
                    }
                }, bn.apply(this, arguments)
            }

            function yn(t, e) {
                for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = gn(t));) ;
                return t
            }

            function gn(t) {
                return gn = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
                    return t.__proto__ || Object.getPrototypeOf(t)
                }, gn(t)
            }

            function mn(t, e) {
                kn(t, e), e.add(t)
            }

            function _n(t, e, n) {
                kn(t, e), e.set(t, n)
            }

            function kn(t, e) {
                if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
            }

            function On(t, e) {
                return function (t, e) {
                    return e.get ? e.get.call(t) : e.value
                }(t, Cn(t, e, "get"))
            }

            function Tn(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                return n
            }

            function Sn(t, e, n) {
                return function (t, e, n) {
                    if (e.set) e.set.call(t, n); else {
                        if (!e.writable) throw new TypeError("attempted to set read only private field");
                        e.value = n
                    }
                }(t, Cn(t, e, "set"), n), n
            }

            function Cn(t, e, n) {
                if (!e.has(t)) throw new TypeError("attempted to " + n + " private field on non-instance");
                return e.get(t)
            }

            var xn = new WeakMap, jn = new WeakMap, Pn = new WeakSet, En = new WeakSet, In = new WeakSet,
                Wn = new WeakSet, Rn = new WeakSet, zn = new WeakSet, An = new WeakSet, Hn = new WeakSet,
                Dn = function (t) {
                    !function (t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                writable: !0,
                                configurable: !0
                            }
                        }), Object.defineProperty(t, "prototype", {writable: !1}), e && dn(t, e)
                    }(i, t);
                    var e, n, o, r, a = (o = i, r = function () {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function () {
                            }))), !0
                        } catch (t) {
                            return !1
                        }
                    }(), function () {
                        var t, e = gn(o);
                        if (r) {
                            var n = gn(this).constructor;
                            t = Reflect.construct(e, arguments, n)
                        } else t = e.apply(this, arguments);
                        return vn(this, t)
                    });

                    function i(t, e) {
                        var n;
                        return function (t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, i), mn(wn(n = a.call(this)), Hn), mn(wn(n), An), mn(wn(n), zn), mn(wn(n), Rn), mn(wn(n), Wn), mn(wn(n), In), mn(wn(n), En), mn(wn(n), Pn), _n(wn(n), xn, {
                            writable: !0,
                            value: void 0
                        }), _n(wn(n), jn, {writable: !0, value: void 0}), Sn(wn(n), xn, t), Sn(wn(n), jn, e), n
                    }

                    return e = i, (n = [{
                        key: "init", value: function () {
                            var t = this;
                            pn(document).on("mouseenter", ".wh_top_menu li", (function (e) {
                                return Tn(t, Pn, Mn).call(t, e)
                            })), pn(document).on("mouseleave", ".wh_top_menu li", (function (t) {
                                var e = pn(t.currentTarget).children(".topicref");
                                e.attr(de) !== me && (pn(t.currentTarget).attr("aria-expanded", "false"), e.attr(de, ye))
                            })), pn(document).on("click", ".wh_top_menu li", (function (t) {
                                pn(".wh_top_menu li").removeClass("active"), pn(t.currentTarget).addClass("active"), pn(t.currentTarget).parents("li").addClass("active"), t.stopImmediatePropagation()
                            })), pn(document).on({
                                click: function (t) {
                                    var e = pn(".wh_top_menu");
                                    e.is(t.target) || 0 !== e.has(t.target).length || pn(".wh_top_menu li.active").removeClass("active")
                                }, keydown: function (t) {
                                    27 === t.which && pn(".wh_top_menu li.active").removeClass("active")
                                }
                            });
                            var e = s.Options.getBoolean("webhelp.top.menu.activated.on.click");
                            pn(document).on("click", ".wh_top_menu a", (function (n) {
                                var o;
                                if (void 0 !== n.pointerType && (o = n.pointerType), !(e || pn(window).width() < 767 || On(t, jn) || "touch" == o)) return !0;
                                var r = pn(n.currentTarget).closest("li"), a = r.hasClass("active"),
                                    i = r.hasClass("has-children");
                                if (a || !i) return window.location = pn(n.currentTarget).attr("href"), n.preventDefault(), n.stopImmediatePropagation(), !1;
                                n.preventDefault()
                            }))
                        }
                    }]) && hn(e.prototype, n), Object.defineProperty(e, "prototype", {writable: !1}), i
                }(Ee);

            function Mn(t) {
                var e = pn(t.currentTarget), n = e.children(".topicref"), o = n.attr(de);
                if (o === we) ; else if (o === be) {
                    n.attr(de, we);
                    var r = n.attr("id"), a = pn("<span>", {class: "dot"}), i = pn("<ul>", {
                        class: "loading",
                        "aria-labelledby": r,
                        role: "menu",
                        html: pn("<li>", {role: "menuitem", html: [a, a.clone(), a.clone()]})
                    });
                    J.DOMSanitizer.appendHtmlNode(i, e), Tn(this, En, Ln).call(this, e), Tn(this, In, Nn).call(this, n)
                } else o === ge ? Tn(this, En, Ln).call(this, e) : o === ye && n.attr(de, ge);
                null != e.attr("aria-expanded") && e.attr("aria-expanded", "true")
            }

            function Ln(t) {
                var e, n = On(this, xn) ? "left" : "right", o = pn(".wh_top_menu ul").index(t.parent("ul")),
                    r = parseInt(t.offset().left), a = r + parseInt(t.width()), i = parseInt(t.children("ul").width()),
                    l = a + i;
                0 == o ? "left" == n ? (t.attr("data-menuDirection", "left"), (e = a - i) <= 0 && (t.css("position", "relative"), t.children("ul").css("position", "absolute"), t.children("ul").css("right", "auto"), t.children("ul").css("left", "0"))) : (t.attr("data-menuDirection", "right"), (l = r + i) >= pn(window).width() && (t.css("position", "relative"), t.children("ul").css("position", "absolute"), t.children("ul").css("right", "0"), t.children("ul").css("left", "auto"))) : (e = r - i, "left" == n ? e >= 0 ? (t.attr("data-menuDirection", "left"), t.children("ul").css("right", "100%"), t.children("ul").css("left", "auto")) : (t.attr("data-menuDirection", "right"), t.children("ul").css("right", "auto"), t.children("ul").css("left", "100%")) : l <= pn(window).width() ? (t.attr("data-menuDirection", "right"), t.children("ul").css("right", "auto"), t.children("ul").css("left", "100%")) : (t.attr("data-menuDirection", "left"), t.children("ul").css("right", "100%"), t.children("ul").css("left", "auto")))
            }

            function Nn(t) {
                var e = this, n = pn(t).attr(ve);
                null != n && P.Z.loadJS("./" + bn(gn(Dn.prototype), "_getPathToRoot", this).call(this) + "oxygen-webhelp/app/nav-links/json/" + n + ".js", (function () {
                    var o = oxy_webhelp_navlinks[n];
                    if (null != o) {
                        var r = o.topics, a = t.closest("li"), i = Tn(e, Wn, Bn).call(e, r),
                            l = a.children("ul.loading");
                        l.find("li").remove(), l.removeClass("loading"), i.forEach((function (t) {
                            return l.append(t)
                        })), t.attr(de, ge)
                    } else t.attr(de, me)
                }))
            }

            function Bn(t) {
                var e = this, n = [];
                return t.forEach((function (t) {
                    if (!t.menu.isHidden) {
                        var o = Tn(e, Rn, Zn).call(e, t);
                        n.push(o)
                    }
                })), n
            }

            function Zn(t) {
                var e = pn('<li role="menuitem">');
                t.menu.hasChildren && (e.addClass("has-children"), e.attr("aria-haspopup", "true"), e.attr("aria-expanded", "false"));
                var n = t.menu.image;
                if (null != n && null != n.href) {
                    var o = Tn(this, zn, Un).call(this, t);
                    e.append(o)
                }
                var r = Tn(this, An, Jn).call(this, t);
                return e.append(r), e
            }

            function Un(t) {
                var e = t.menu.image, n = pn("<span>", {class: "topicImg"}), o = "";
                "external" == e.scope || (o += bn(gn(Dn.prototype), "_getPathToRoot", this).call(this)), o += e.href;
                var r = pn("<img>", {src: o, alt: t.title});
                return null != e.height && r.attr("height", e.height), null != e.width && r.attr("width", e.width), J.DOMSanitizer.appendHtmlNode(r, n), n
            }

            function Jn(t) {
                var e = "external" == t.scope, n = pn("<span>");
                n.addClass("topicref"), null != t.outputclass && n.addClass(t.outputclass);
                var o = t.attributes;
                void 0 !== o && Object.keys(o).forEach((function (t) {
                    return n.attr(t, o[t])
                })), n.attr(ve, t.tocID), n.attr("id", t.tocID + "-mi"), Tn(this, Hn, Fn).call(this, t) ? n.attr(de, be) : n.attr(de, me);
                var r = "";
                null != t.href && "javascript:void(0)" != t.href && (e || (r += bn(gn(Dn.prototype), "_getPathToRoot", this).call(this)), r += t.href);
                var a = pn("<a>", {href: r, html: t.title}),
                    i = bn(gn(Dn.prototype), "_getPathToRoot", this).call(this);
                a.find("a[href]").each((function (t, e) {
                    var n = pn(e).attr("href");
                    n.startsWith("http:") || n.startsWith("https:") || pn(e).attr("href", i + n)
                })), a.find("img[src]").each((function (t, e) {
                    var n = pn(e).attr("src");
                    n.startsWith("http:") || n.startsWith("https:") || pn(e).attr("src", i + n)
                })), e && a.attr("target", "_blank");
                var l = pn("<span>", {class: "title"});
                return J.DOMSanitizer.appendHtmlNode(a, l), J.DOMSanitizer.appendHtmlNode(l, n), n
            }

            function Fn(t) {
                var e = t.topics;
                return (null == e || 0 != e.length) && (null == t.menu || t.menu.hasChildren)
            }

            var $n = !1;
            "rtl" == pn("html").attr("dir") && ($n = !0);
            var qn = !1;
            try {
                document.createEvent("TouchEvent") && (qn = !0)
            } catch (t) {
                P.Z.debug(t)
            }
            var Qn = new Dn($n, qn);

            function Gn(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function Xn(t, e, n) {
                return e && Gn(t.prototype, e), n && Gn(t, n), Object.defineProperty(t, "prototype", {writable: !1}), t
            }

            var Yn = Xn((function t(e, n, o) {
                !function (t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }(this, t), this.label = e, this.value = n, this.type = o
            }));

            function Kn(t) {
                ft.setCustomAutocomplete(t), ft.install()
            }

            n(3193)((function () {
                s.Options.getBoolean("webhelp.enable.sticky.header") && j.stickyController.init(), Qn.init(), un.init(), ie.init(), c.init(), k.init(), x.init(), he.init(), kt.initialize(), kt.keepLastSearchExpression()
            }))
        }, 4290: (t, e, n) => {
            function o(t, e) {
                if (t) {
                    if ("string" == typeof t) return r(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(t, e) : void 0
                }
            }

            function r(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, o = new Array(e); n < e; n++) o[n] = t[n];
                return o
            }

            function a(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            n.d(e, {Z: () => i});
            var i = function () {
                function t() {
                    !function (t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t)
                }

                var e, n;
                return e = t, n = [{
                    key: "getParameter", value: function (t) {
                        var e, n, r, a = new URLSearchParams(window.location.search), i = new URLSearchParams,
                            l = function (t, e) {
                                var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                                if (!n) {
                                    if (Array.isArray(t) || (n = o(t))) {
                                        n && (t = n);
                                        var r = 0, a = function () {
                                        };
                                        return {
                                            s: a, n: function () {
                                                return r >= t.length ? {done: !0} : {done: !1, value: t[r++]}
                                            }, e: function (t) {
                                                throw t
                                            }, f: a
                                        }
                                    }
                                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                }
                                var i, l = !0, c = !1;
                                return {
                                    s: function () {
                                        n = n.call(t)
                                    }, n: function () {
                                        var t = n.next();
                                        return l = t.done, t
                                    }, e: function (t) {
                                        c = !0, i = t
                                    }, f: function () {
                                        try {
                                            l || null == n.return || n.return()
                                        } finally {
                                            if (c) throw i
                                        }
                                    }
                                }
                            }(a);
                        try {
                            for (l.s(); !(e = l.n()).done;) {
                                var c = (n = e.value, r = 2, function (t) {
                                    if (Array.isArray(t)) return t
                                }(n) || function (t, e) {
                                    var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                                    if (null != n) {
                                        var o, r, a = [], i = !0, l = !1;
                                        try {
                                            for (n = n.call(t); !(i = (o = n.next()).done) && (a.push(o.value), !e || a.length !== e); i = !0) ;
                                        } catch (t) {
                                            l = !0, r = t
                                        } finally {
                                            try {
                                                i || null == n.return || n.return()
                                            } finally {
                                                if (l) throw r
                                            }
                                        }
                                        return a
                                    }
                                }(n, r) || o(n, r) || function () {
                                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                }()), s = c[0], u = c[1];
                                i.append(s.toLowerCase(), u)
                            }
                        } catch (t) {
                            l.e(t)
                        } finally {
                            l.f()
                        }
                        var p = i.get(t.toLowerCase());
                        return p && (p = (p = decodeURIComponent(p)).replace(/\+/g, " ")), p
                    }
                }, {
                    key: "loadJS", value: function (t, e) {
                        var n = document.createElement("script");
                        n.src = t, n.onload = e, n.onreadystatechange = e, document.body.appendChild(n)
                    }
                }, {
                    key: "isLocal", value: function () {
                        this.debug("isLocal()");
                        try {
                            var t = window.location.protocol;
                            if (t.includes("http") || t.includes("https")) return !1
                        } catch (t) {
                            this.debug(t)
                        }
                        return !0
                    }
                }, {
                    key: "debug", value: function (t, e) {
                    }
                }], null && a(e.prototype, null), n && a(e, n), Object.defineProperty(e, "prototype", {writable: !1}), t
            }()
        }, 4093: t => {
            t.exports = properties
        }
    }, n = {};

    function o(t) {
        var r = n[t];
        if (void 0 !== r) return r.exports;
        var a = n[t] = {exports: {}};
        return e[t].call(a.exports, a, a.exports, o), a.exports
    }

    o.m = e, t = [], o.O = (e, n, r, a) => {
        if (!n) {
            var i = 1 / 0;
            for (u = 0; u < t.length; u++) {
                for (var [n, r, a] = t[u], l = !0, c = 0; c < n.length; c++) (!1 & a || i >= a) && Object.keys(o.O).every((t => o.O[t](n[c]))) ? n.splice(c--, 1) : (l = !1, a < i && (i = a));
                if (l) {
                    t.splice(u--, 1);
                    var s = r();
                    void 0 !== s && (e = s)
                }
            }
            return e
        }
        a = a || 0;
        for (var u = t.length; u > 0 && t[u - 1][2] > a; u--) t[u] = t[u - 1];
        t[u] = [n, r, a]
    }, o.n = t => {
        var e = t && t.__esModule ? () => t.default : () => t;
        return o.d(e, {a: e}), e
    }, o.d = (t, e) => {
        for (var n in e) o.o(e, n) && !o.o(t, n) && Object.defineProperty(t, n, {enumerable: !0, get: e[n]})
    }, o.g = function () {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (t) {
            if ("object" == typeof window) return window
        }
    }(), o.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e), o.r = t => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {value: "Module"}), Object.defineProperty(t, "__esModule", {value: !0})
    }, o.j = "topic", (() => {
        var t = {topic: 0};
        o.O.j = e => 0 === t[e];
        var e = (e, n) => {
            var r, a, [i, l, c] = n, s = 0;
            if (i.some((e => 0 !== t[e]))) {
                for (r in l) o.o(l, r) && (o.m[r] = l[r]);
                if (c) var u = c(o)
            }
            for (e && e(n); s < i.length; s++) a = i[s], o.o(t, a) && t[a] && t[a][0](), t[a] = 0;
            return o.O(u)
        }, n = self.webpackChunkwebhelp = self.webpackChunkwebhelp || [];
        n.forEach(e.bind(null, 0)), n.push = e.bind(null, n.push.bind(n))
    })();
    var r = o.O(void 0, ["commons"], (() => o(2404)));
    r = o.O(r), WebHelpAPI = r
})();
//